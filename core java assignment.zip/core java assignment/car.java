package gcp_assesment1;

 

import java.util.Scanner;

 

public class CarAssignment1 {

              private String carModel;

              private String carType;

              private double carPrice;

              private String insuranceType;

             

              public String getCarModel() {

                           return carModel;

              }

 

              public void setCarModel(String carModel) {

                           this.carModel = carModel;

              }

 

              public String getCarType() {

                           return carType;

              }

 

              public void setCarType(String carType) {

                           this.carType = carType;

              }

 

              public double getCarPrice() {

                           return carPrice;

              }

 

              public void setCarPrice(double carPrice) {

                           this.carPrice = carPrice;

              }

 

              public String getInsuranceType() {

                           return insuranceType;

              }

 

              public void setInsuranceType(String insuranceType) {

                           this.insuranceType = insuranceType;

              }

              public double getActualamount()

              {

                           double amount;

                           double insurancePremium;

                           String type = this.getCarType();

                           String insuranceType = this.getInsuranceType();

                           if(type.equalsIgnoreCase("Hatchback"))

                           {           

                                                       if(insuranceType.equalsIgnoreCase("Premium"))

                                                       {

                                                                    insurancePremium = (0.05)*(this.getCarPrice());

                                                                    amount = insurancePremium + ((0.2)*(insurancePremium));

                                                       }

                                                       else

                                                       {

                                                                    amount = (0.05)*(this.getCarPrice());

                                                       }

                           }

                           else if(type.equalsIgnoreCase("Sedan"))

                           {           

                                         if(insuranceType.equalsIgnoreCase("Premium"))

                                         {

                                                       insurancePremium = (0.08)*(this.getCarPrice());

                                                       amount = insurancePremium + ((0.2)*(insurancePremium));

                                         }

                                         else

                                         {

                                                       amount = (0.08)*(this.getCarPrice());

                                         }

                           }

                           else

                           {           

                                         if(insuranceType.equalsIgnoreCase("Premium"))

                                         {

                                                       insurancePremium = (0.01)*(this.getCarPrice());

                                                       amount = insurancePremium + ((0.2)*(insurancePremium));

                                         }

                                         else

                                         {

                                                       amount = (0.01)*(this.getCarPrice());

                                         }

                           }

                           return amount;

              }

              public String toString()

              {

                           return("Car Cost price = "+this.getCarPrice()+"\n"+"Car Type = "+this.getCarType()+"\n"+"Car Model = "+this.getCarModel()+"\n"+"Car Insurance Type = "+this.getInsuranceType()+"\n"+"Hence amount to be paid = "+this.getActualamount());

              }

              public static void main(String[] args) {

                           // TODO Auto-generated method stub

                           try

                           {

                                         Scanner inp = new Scanner(System.in);

                                         String option="";

                                         do

                                         {

                                                       CarAssignment1 c = new CarAssignment1();

                                                       System.out.println("Enter Car details");

                                                       System.out.println("Car Model");

                                                       c.setCarModel(inp.nextLine());

                                                       System.out.println("Car Type");

                                                       c.setCarType(inp.nextLine());

                                                       System.out.println("Car Cost Price");

                                                       c.setCarPrice(inp.nextDouble());

                                                       System.out.println("Car Insurance Type");

                                                       String insType = inp.nextLine();

                                                       if(insType == "Premium" || insType == "Basic")

                                                       {

                                                                    c.setInsuranceType(insType);

                                                       }

                                                       else

                                                       {

                                                                    System.out.println("Please enter valid Insurance Type \nHint :\n Basic \n Premium");

                                                                    insType = inp.nextLine();

                                                                    c.setInsuranceType(insType);

                                                       }

                                                       System.out.println(c);

                                                       System.out.println("Do you want to enter details of any other car \n please enter Y to continue and N to stop");

                                                       option = inp.nextLine();

                                         }while(option.equalsIgnoreCase("Y"));

                                         System.out.println("Execution Completed Successfully");

                                        

                           }catch(Exception e)

                           {

                                         System.out.println("Please check your inputs");

                           }

                          

              }

 

}